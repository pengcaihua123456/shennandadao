#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_sport_yuedong_com_myapplication_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "20200508";
    return env->NewStringUTF(hello.c_str());
}
