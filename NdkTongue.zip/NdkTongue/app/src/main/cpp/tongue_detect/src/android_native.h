#ifndef __ANDROID_NATIVE_H__
#define __ANDROID_NATIVE_H__

#include <string>

typedef struct _TongueInfo {
    bool isTongue;
    float togueLocation[4];
} TongueInfo;

#endif
