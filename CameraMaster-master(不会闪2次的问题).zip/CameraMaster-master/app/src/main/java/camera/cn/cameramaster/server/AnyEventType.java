package camera.cn.cameramaster.server;

/**
 * event bus 消息类
 *
 * @packageName: cn.tongue.tonguecamera.eventbus
 * @fileName: AnyEventType
 * @date: 2019/4/24  18:36
 * @author: ymc
 * @QQ:745612618
 */

public class AnyEventType {

    public AnyEventType(){}

}
