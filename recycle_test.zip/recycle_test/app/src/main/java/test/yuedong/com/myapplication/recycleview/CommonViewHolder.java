package test.yuedong.com.myapplication.recycleview;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by virl on 15/10/4.
 */
public class CommonViewHolder extends RecyclerView.ViewHolder {
    public CommonViewHolder(View itemView) {
        super(itemView);
    }
}
