package test.yuedong.com.myapplication;

public class MyDeviceAdapter{


}


//public class MyDeviceAdapter extends BaseMultiItemQuickAdapter<MyDeviceBean.DeviceInfo, BaseViewHolder> {
//
//
//    public MyDeviceAdapter(Context context) {
//        super(null);
//        this.mContext = context;
//        addItemType(MyDeviceBean.DeviceInfo.ITEM_TYPE_PHOTO, R.layout.item_device_info);
//    }
//
//
//    @Override
//    protected void convert(BaseViewHolder helper, MyDeviceBean.DeviceInfo item) {
//
//        String device_name = item.device_name;
//        if (!TextUtils.isEmpty(device_name)) {
//            helper.setText(R.id.tv_device_connect_name, String.valueOf(device_name));
//        }
//
//    }
//}
