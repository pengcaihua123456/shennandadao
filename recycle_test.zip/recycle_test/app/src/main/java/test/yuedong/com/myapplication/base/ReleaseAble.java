package test.yuedong.com.myapplication.base;

/**
 * Created by virl on 15/5/18.
 */
public interface ReleaseAble {
    public void release();
}
