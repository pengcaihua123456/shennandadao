package test.yuedong.com.myapplication.base;

/**
 * Created by virl on 15/6/18.
 */
public interface OnDestroyObserver {
    void onDestroy();
}
