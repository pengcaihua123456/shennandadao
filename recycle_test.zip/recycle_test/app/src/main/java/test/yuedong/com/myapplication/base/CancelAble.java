package test.yuedong.com.myapplication.base;

/**
 * Created by virl on 15/8/19.
 */
public interface CancelAble {
    void cancel();
}
