package test.yuedong.com.myapplication.bitmap;

import android.graphics.Bitmap;

/**
 * Created by virl on 15/8/1.
 */
public interface IImageLoader {
    Bitmap loadBitmap(String path);
}
