package top.daxianwill.greendaodemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.greendao.gen.UserDao;

import java.util.ArrayList;
import java.util.List;

/**
 * 数据库操作类
 */
public class MainActivity extends AppCompatActivity {

    private ListView mListView;//列表组件对象

    private List<User> mUserList = new ArrayList<>();//存放列表数据的集合

    private MyAdapter mAdapter;//列表适配器

    private User mUser;//实体类

    private UserDao mUserDao;//数据库操作类（Greendao自动生成）

    private long id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        mListView = findViewById(R.id.list_view);

        mAdapter = new MyAdapter(this,mUserList);

        mListView.setAdapter(mAdapter);

        mUserDao = MyApplication.getInstances().getDaoSession().getUserDao();

        mUserDao.deleteAll();//删除所有数据
    }

    /**
     * 增
     */
    public void insert(){

        mUser = new User(id++,"any"+id);

        mUserDao.insert(mUser);

        notifyListView();
    }

    /**
     * 删
     */
    public void delete(){

        long l = mUserDao.count() - 1;

        mUserDao.deleteByKey(l);

        notifyListView();
    }

    /**
     * 改
     */
    public void update(){

        mUser = new User((long)3,"any0803");

        mUserDao.update(mUser);

        notifyListView();
    }

    /**
     * 查
     */
    public void loadAll(){

        mUserList = mUserDao.loadAll();//查询所有数据

        notifyListView();
    }

    /**
     * 更新ListView
     */
    public void notifyListView(){

        mUserList.clear();

        mUserList = mUserDao.loadAll();

        mAdapter = new MyAdapter(MainActivity.this,mUserList);

        mListView.setAdapter(mAdapter);
    }

}
